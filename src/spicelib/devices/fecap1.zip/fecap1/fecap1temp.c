/**********
Copyright 2024 Xidian University
Author: 2024 Bo Li
Modified: 2024/01/27  Bo Li
Refered to NgSPICE Res/Cap related file
**********/
/*
 */

/* load the capacitor structure with those pointers needed later
 * for fast matrix loading
 */

#include "ngspice/ngspice.h"
#include "ngspice/cktdefs.h"
#include "fecap1defs.h"
#include "ngspice/sperror.h"
#include "ngspice/suffix.h"


/*ARGSUSED*/
int
FECAP1temp(GENmodel *inModel, CKTcircuit *ckt)

{
    FECAP1model *model = (FECAP1model*)inModel;
    FECAP1instance *here;
    double difference;
    double factor;
    double tc1, tc2;

    /*  loop through all the capacitor models */
    for( ; model != NULL; model = FECAP1nextModel(model)) {

        /* loop through all the instances of the model */
        for (here = FECAP1instances(model); here != NULL ;
                here=FECAP1nextInstance(here)) {

            /* Default Value Processing for FECAP1acitor Instance */
            if(!here->FECAP1tempGiven) {
                here->FECAP1temp   = ckt->CKTtemp;
                if(!here->FECAP1dtempGiven)   here->FECAP1dtemp  = 0.0;
            } else { /* FECAP1tempGiven */
                here->FECAP1dtemp = 0.0;
                if (here->FECAP1dtempGiven)
                    printf("%s: Instance temperature specified, dtemp ignored\n",
                           here->FECAP1name);
            }

            if (!here->FECAP1widthGiven) {
                here->FECAP1width = model->FECAP1defWidth;
            }
            if (!here->FECAP1scaleGiven) here->FECAP1scale = 1.0;
            if (!here->FECAP1mGiven)     here->FECAP1m     = 1.0;

            if (!here->FECAP1capGiven)  { /* No instance capacitance given */
                if (!model->FECAP1mCapGiven) { /* No model capacitange given */
                    here->FECAP1capac =
                        model->FECAP1cj *
                        (here->FECAP1width - model->FECAP1narrow) *
                        (here->FECAP1length - model->FECAP1short) +
                        model->FECAP1cjsw * 2 * (
                            (here->FECAP1length - model->FECAP1short) +
                            (here->FECAP1width - model->FECAP1narrow) );
                } else {
                    here->FECAP1capac = model->FECAP1mCap;
                }
            }

            difference = (here->FECAP1temp + here->FECAP1dtemp) - model->FECAP1tnom;

            /* instance parameters tc1 and tc2 will override
               model parameters tc1 and tc2 */
            if (here->FECAP1tc1Given)
                tc1 = here->FECAP1tc1; /* instance */
            else
                tc1 = model->FECAP1tempCoeff1; /* model */

            if (here->FECAP1tc2Given)
                tc2 = here->FECAP1tc2;
            else
                tc2 = model->FECAP1tempCoeff2;

            factor = 1.0 + tc1*difference +
                     tc2*difference*difference;

            here->FECAP1capac = here->FECAP1capac * factor * here->FECAP1scale;

        }
    }

    return(OK);
}

