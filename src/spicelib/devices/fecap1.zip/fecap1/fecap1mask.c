/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
Author: 1985 Thomas L. Quarles
Modified: September 2003 Paolo Nenzi
**********/
/*
 */

#include "ngspice/ngspice.h"
#include "ngspice/cktdefs.h"
#include "ngspice/devdefs.h"
#include "fecap1defs.h"
#include "ngspice/sperror.h"
#include "ngspice/ifsim.h"
#include "ngspice/suffix.h"


/* ARGSUSED */
int
FECAP1mAsk(CKTcircuit *ckt, GENmodel *inst, int which, IFvalue *value)
{
    FECAP1model *model = (FECAP1model*)inst;

    NG_IGNORE(ckt);

    switch(which) {
    case FECAP1_MOD_TNOM:
        value->rValue = model->FECAP1tnom-CONSTCtoK;
        return(OK);
    /*    
    case FECAP1_MOD_TC1:
        value->rValue = here->FECAP1tempCoeff1;
        return(OK);
    case FECAP1_MOD_TC2:
        value->rValue = here->FECAP1tempCoeff2;
        return(OK);
    */

    case FECAP1_MOD_FECAP1:
        value->rValue = model->FECAP1mFECAP1;
        return(OK);
    /*    
    case FECAP1_MOD_CJ:
        value->rValue = here->FECAP1cj;
        return(OK);
    case FECAP1_MOD_CJSW:
        value->rValue = here->FECAP1cjsw;
        return(OK);
    case FECAP1_MOD_DEFWIDTH:
        value->rValue = here->FECAP1defWidth;
        return(OK);
    case FECAP1_MOD_DEFLENGTH:
        value->rValue = here->FECAP1defLength;
        return(OK);
    case FECAP1_MOD_NARROW:
        value->rValue = here->FECAP1narrow;
        return(OK);
    case FECAP1_MOD_SHORT:
        value->rValue = here->FECAP1short;
        return(OK);
    case FECAP1_MOD_DEL:
        value->rValue = here->FECAP1del;
        return(OK);
    case FECAP1_MOD_DI:
        value->rValue = here->FECAP1di;
        return(OK);
    case FECAP1_MOD_BV_MAX:
        value->rValue = here->FECAP1bv_max;
        return(OK);

    */    
    case FECAP1_MOD_Depth:
        value->rValue = model->FECAP1d;
        return(OK);

    case FECAP1_MOD_WF: 
        value->rValue = model->FECAP1defWf; 
        return(OK); 
    
    case FECAP1_MOD_N: 
        value->rValue = model->FECAP1defN; 
        return(OK); 

    case FECAP1_MOD_Ec: 
        value->rValue = model->FECAP1defEc; 
        return(OK);

    case FECAP1_MOD_Pr: 
        value->rValue = model->FECAP1defPr; 
        return(OK);

    case FECAP1_MOD_RHO: 
        value->rValue = model->FECAP1defRHO; 
        return(OK);

    default:
        return(E_BADPARM);
    }
}
