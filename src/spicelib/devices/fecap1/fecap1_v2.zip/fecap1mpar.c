/**********
Copyright 2024 Xidian University.	All rights reserved.
 Author: Bo Li	at Hangzhou Institute of Technology	 
 Modified: 2024/1/27  Bo Li
 Refered to NgSPICE Res/Cap related file
**********/

/*
 */

#include "ngspice/ngspice.h"
#include "ngspice/ifsim.h"
#include "capdefs.h"
#include "ngspice/sperror.h"
#include "ngspice/suffix.h"


int
FECAP1mParam(int param, IFvalue *value, GENmodel *inModel)
{
    FECAP1model *mod = (FECAP1model*)inModel;
    switch(param) {

    case FECAP1_MOD_Depth:
        mod->CAPthick = value->rValue;
        mod->CAPthickGiven = TRUE;
        break;

    case FECAP1_MOD_TNOM:
        mod->FECAP1tnom = value->rValue+CONSTCtoK;
        mod->FECAP1tnomGiven = TRUE;
        break;

	case FECAP1_MOD_WF: 
		mod->FECAP1defWf=value->rValue; 
		mod->FECAP1defWfGiven = TRUE; 
		break;
		
	case FECAP1_MOD_N: 
		mod->FECAP1defN=value->rValue; 
		mod->FECAP1defNGiven=TRUE; 
		break;
		
	case FECAP1_MOD_FECAP: 
		if(value->iValue){ 
			mod->FECAP1type = 1; 
			mod->FECAP1typeGiven = TRUE; 
		}
		break;        

    case FECAP1_MOD_T_FE: 
		mod->FECAP1deftFE = value->rValue; 
		mod->FECAP1deftFEGiven = TRUE; 
		break;

    case FECAP1_MOD_Ec: 
		mod->FECAP1defEc = value->rValue; 
		mod->FECAP1defEcGiven = TRUE; 
		break;

    case FECAP1_MOD_Pr: 
		mod->FECAP1defPr = value->rValue; 
		mod->FECAP1defPrGiven = TRUE; 
		break;

    case FECAP1_MOD_RHO: 
		mod->FECAP1defRHO = value->rValue; 
		mod->FECAP1defRHOGiven = TRUE; 
		break;          
    /*    
    case CAP_MOD_TC1:
        mod->CAPtempCoeff1 = value->rValue;
        mod->CAPtc1Given = TRUE;
        break;
    case CAP_MOD_TC2:
        mod->CAPtempCoeff2 = value->rValue;
        mod->CAPtc2Given = TRUE;
        break;

    case CAP_MOD_CAP:
        mod->CAPmCap = value->rValue;
        mod->CAPmCapGiven = TRUE;
        break;
    case CAP_MOD_CJ :
        mod->CAPcj = value->rValue;
        mod->CAPcjGiven = TRUE;
        break;
    case CAP_MOD_CJSW :
        mod->CAPcjsw = value->rValue;
        mod->CAPcjswGiven = TRUE;
        break;

    case CAP_MOD_DEFWIDTH:
        mod->CAPdefWidth = value->rValue;
        mod->CAPdefWidthGiven = TRUE;
        break;
    case CAP_MOD_DEFLENGTH:
        mod->CAPdefLength = value->rValue;
        mod->CAPdefLengthGiven = TRUE;
        break;
    case CAP_MOD_NARROW:
        mod->CAPnarrow = value->rValue;
        mod->CAPnarrowGiven = TRUE;
        break;
    case CAP_MOD_SHORT:
        mod->CAPshort = value->rValue;
        mod->CAPshortGiven = TRUE;
        brseak;
    case CAP_MOD_DEL:
        mod->CAPdel = value->rValue;
        mod->CAPdelGiven = TRUE;
        break;
    case CAP_MOD_DI:
        mod->CAPdi = value->rValue;
        mod->CAPdiGiven = TRUE;
        break;
    */    

    
    /*
    case CAP_MOD_BV_MAX:
        mod->CAPbv_max = value->rValue;
        mod->CAPbv_maxGiven = TRUE;
        break;
    */    
    default:
        return(E_BADPARM);
    }
    return(OK);
}

