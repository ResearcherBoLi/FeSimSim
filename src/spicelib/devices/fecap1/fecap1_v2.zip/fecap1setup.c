/**********
Copyright 2024 Xidian University
Author: 2024 Bo Li
Modified: 2024/01/27  Bo Li
Refered to NgSPICE Res/Cap related file
**********/
/*
 */

#include "ngspice/ngspice.h"
#include "ngspice/cktdefs.h"
#include "fecap1defs.h"
#include "ngspice/sperror.h"
#include "ngspice/suffix.h"


/*ARGSUSED*/
int
FECAP1setup(SMPmatrix *matrix, GENmodel *inModel, CKTcircuit *ckt, int *states)
        /* load the capacitor structure with those pointers needed later
         * for fast matrix loading
         */

{
    FECAP1model *model = (FECAP1model*)inModel;
    FECAP1instance *here;

    /*  loop through all the capacitor models */
    for( ; model != NULL; model = FECAP1nextModel(model)) {

        /*Default Value Processing for Model Parameters */

        if (!model->FECAP1defWidthGiven) {
            model->FECAP1_Width = 10.e-6;
        }
        if (!model->FECAP1defLengthGiven) {
            model->FECAP_Length = 0.0;
        }
        
        if (!model->FECAP1thickGiven) {
            model->FECAP1_T_FE = 1e-9;
        }
        if (!model->FECAP1defAreaGiven) {
            model->FECAP1_Area = 1e-14;
        }
        if (!model->FECAP1defPrGiven) model->FECAP1_Pr = 27.54;
        if (!model->FECAP1defPsGiven) model->FECAP1_Ps = 27.54;		
        if (!model->FECAP1defEcGiven) model->FECAP1_Ec = 1.175;
        }
        if (!model->FECAP1defpGiven) {
            model->FECAP1_p =18;

        if (!model->FECAP1delGiven) {
            model->FECAP1del = 0.0;
        }
        if (!model->FECAP1tc1Given) {
            model->FECAP1tempCoeff1 = 0.0;
        }
        if (!model->FECAP1tc2Given) {
            model->FECAP1tempCoeff2 = 0.0;
        }
        if (!model->FECAP1tnomGiven)  model->FECAP1tnom = ckt->CKTnomTemp;

		if(!model->FECAP1defEpilon) model->FECAP1_Epilon = 1.3;
		


        /* loop through all the instances of the model */
        for (here = FECAP1instances(model); here != NULL ;
                here=FECAP1nextInstance(here)) {


			
			if(here->FECAP1Ibranch == 0) { 
				error = CKTmkCur(ckt,&tmp,here->FECAP1name,"ibranch"); 
				if(error) return(error); 
				here->FECAP1Ibranch = tmp->number; 
			} 


			if(here->FECAP1Pbranch == 0) { 
				error = CKTmkCur(ckt,&tmp,here->FECAP1name,"pbranch"); 
				if(error) return(error); 
				here->FECAP1Pbranch = tmp->number; 
			} 

            here->FECAP1qcap = *states;
            *states += FECAP1numStates;

			here->FECAP1pcap  = *states+1; 
			//*states += FECAP1numStates; 


/* macro to make elements with built in test for out of memory */
#define TSTALLOC(ptr,first,second) \
do { if((here->ptr = SMPmakeElt(matrix, here->first, here->second)) == NULL){\
    return(E_NOMEM);\
} } while(0)

            TSTALLOC(FECAP1posPosPtr,FECAP1posNode,FECAP1posNode);
			TSTALLOC(FECAP1posNegPtr,FECAP1posNode,FECAP1negNode);
			TSTALLOC(FECAP1posIbrPtr, FECAP1posNode, FECAP1Ibranch); 

            TSTALLOC(FECAP1negPosPtr,FECAP1negNode,FECAP1posNode);
            TSTALLOC(FECAP1negNegPtr,FECAP1negNode,FECAP1negNode);            
			TSTALLOC(FECAP1negIbrPtr, FECAP1negNode, FECAP1Ibranch); 
			
			TSTALLOC(FECAP1ibrPosPtr, FECAP1Ibranch, FECAP1posNode); 
			TSTALLOC(FECAP1ibrNegPtr, FECAP1Ibranch, FECAP1negNode); 
			TSTALLOC(FECAP1ibrIbrPtr, FECAP1Ibranch, FECAP1Ibranch); 
			TSTALLOC(FECAP1ibrPbrPtr, FECAP1Ibranch, FECAP1Wbranch); 
			
			TSTALLOC(FECAP1pbrPosPtr, FECAP1Pbranch, FECAP1posNode); 
			TSTALLOC(FECAP1pbrNegPtr, FECAP1Pbranch, FECAP1negNode); 
			TSTALLOC(FECAP1pbrIbrPtr, FECAP1Pbranch, FECAP1Ibranch); 
			TSTALLOC(FECAP1pbrPbrPtr, FECAP1Pbranch,FECAP1Pbranch); 


        }
    }
    return(OK);
}

