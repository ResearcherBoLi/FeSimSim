/**********
Copyright 2024 Xidian University
Author: 2024 Bo Li
Modified: 2020/09/09  Bo Li
Refered to NgSPICE Res/Cap related file
**********/

#include "ngspice/ngspice.h"
#include "ngspice/cktdefs.h"
#include "ngspice/devdefs.h"
#include "fecap1defs.h"
#include "ngspice/ifsim.h"
#include "ngspice/sperror.h"
#include "ngspice/suffix.h"

/* ARGSUSED */
int
FECAP1ask(CKTcircuit *ckt, GENinstance *inst, int which, IFvalue *value,
       IFvalue *select)
{
    FECAP1instance *here = (FECAP1instance *)inst;
    double vr;
    double vi;
    double sr;
    double si;
    double vm;
    static char *msg = "Current and power not available for ac analysis";

    switch(which) {
        case FECAP1_TEMP:
            value->rValue = here->FECAP1temp - CONSTCtoK;
            return(OK);
        case FECAP1_DTEMP:
            value->rValue = here->FECAP1dtemp;
            return(OK);
        case FECAP1_CAP:
            value->rValue=here->FECAP1capac;
            value->rValue *= here->FECAP1m;
            return(OK);
        case FECAP1_IC_V:
            value->rValue = here->FECAP1initCondV;
            return(OK);
        case FECAP1_IC_P:
            value->rValue = here->FECAP1initCondP;
            return(OK);            
        case FECAP1_WIDTH:
            value->rValue = here->FECAP1width;
            return(OK);
        case FECAP1_LENGTH:
            value->rValue = here->FECAP1length;
            return(OK);
        case FECAP1_SCALE:
            value->rValue = here->FECAP1scale;
            return(OK);
        case FECAP1_BV_MAX:
            value->rValue = here->FECAP1bv_max;
            return(OK);
        case FECAP1_M:
            value->rValue = here->FECAP1m;
            return(OK);
        case FECAP1_TC1:
            value->rValue = here->FECAP1tc1;
            return(OK);
        case FECAP1_TC2:
            value->rValue = here->FECAP1tc2;
            return(OK);
        case FECAP1_CURRENT:
            if (ckt->CKTcurrentAnalysis & DOING_AC) {
                errMsg = TMALLOC(char, strlen(msg) + 1);
                errRtn = "FECAP1ask";
                strcpy(errMsg,msg);
                return(E_ASKCURRENT);
            } else if (ckt->CKTcurrentAnalysis & (DOING_DCOP | DOING_TRCV)) {
                value->rValue = 0;
            } else if (ckt->CKTcurrentAnalysis & DOING_TRAN) {
                if (ckt->CKTmode & MODETRANOP) {
                    value->rValue = 0;
                } else {
                    value->rValue = *(ckt->CKTstate0 + here->FECAP1ccap);
                }
            } else value->rValue = *(ckt->CKTstate0 + here->FECAP1ccap);

            value->rValue *= here->FECAP1m;

            return(OK);
        case FECAP1_POWER:
            if (ckt->CKTcurrentAnalysis & DOING_AC) {
                errMsg = TMALLOC(char, strlen(msg) + 1);
                errRtn = "FECAP1ask";
                strcpy(errMsg,msg);
                return(E_ASKPOWER);
            } else if (ckt->CKTcurrentAnalysis & (DOING_DCOP | DOING_TRCV)) {
                value->rValue = 0;
            } else if (ckt->CKTcurrentAnalysis & DOING_TRAN) {
                if (ckt->CKTmode & MODETRANOP) {
                    value->rValue = 0;
                } else {
                    value->rValue = *(ckt->CKTstate0 + here->FECAP1ccap) *
                            (*(ckt->CKTrhsOld + here->FECAP1posNode) -
                            *(ckt->CKTrhsOld + here->FECAP1negNode));
                }
            } else value->rValue = *(ckt->CKTstate0 + here->FECAP1ccap) *
                            (*(ckt->CKTrhsOld + here->FECAP1posNode) -
                            *(ckt->CKTrhsOld + here->FECAP1negNode));

            value->rValue *= here->FECAP1m;

            return(OK);
        
        /*
        case CAP_QUEST_SENS_DC:
            if(ckt->CKTsenInfo){
               value->rValue = *(ckt->CKTsenInfo->SEN_Sap[select->iValue + 1]+
                    here->CAPsenParmNo);
            }
            return(OK);
        case CAP_QUEST_SENS_REAL:
            if(ckt->CKTsenInfo){
               value->rValue = *(ckt->CKTsenInfo->SEN_RHS[select->iValue + 1]+
                    here->CAPsenParmNo);
            }
            return(OK);
        case CAP_QUEST_SENS_IMAG:
            if(ckt->CKTsenInfo){
               value->rValue = *(ckt->CKTsenInfo->SEN_iRHS[select->iValue + 1]+
                    here->CAPsenParmNo);
            }
            return(OK);
        case CAP_QUEST_SENS_MAG:
            if(ckt->CKTsenInfo){
               vr = *(ckt->CKTrhsOld + select->iValue + 1);
               vi = *(ckt->CKTirhsOld + select->iValue + 1);
               vm = sqrt(vr*vr + vi*vi);
               if(vm == 0){
                 value->rValue = 0;
                 return(OK);
               }
               sr = *(ckt->CKTsenInfo->SEN_RHS[select->iValue + 1]+
                    here->CAPsenParmNo);
               si = *(ckt->CKTsenInfo->SEN_iRHS[select->iValue + 1]+
                    here->CAPsenParmNo);
                   value->rValue = (vr * sr + vi * si)/vm;
            }
            return(OK);
        case CAP_QUEST_SENS_PH:
            if(ckt->CKTsenInfo){
               vr = *(ckt->CKTrhsOld + select->iValue + 1);
               vi = *(ckt->CKTirhsOld + select->iValue + 1);
               vm = vr*vr + vi*vi;
               if(vm == 0){
                 value->rValue = 0;
                 return(OK);
               }
               sr = *(ckt->CKTsenInfo->SEN_RHS[select->iValue + 1]+
                    here->CAPsenParmNo);
               si = *(ckt->CKTsenInfo->SEN_iRHS[select->iValue + 1]+
                    here->CAPsenParmNo);

                   value->rValue = (vr * si - vi * sr)/vm;
            }
            return(OK);

        case CAP_QUEST_SENS_CPLX:
            if(ckt->CKTsenInfo){
                value->cValue.real=
                        *(ckt->CKTsenInfo->SEN_RHS[select->iValue + 1]+
                        here->CAPsenParmNo);
                value->cValue.imag=
                        *(ckt->CKTsenInfo->SEN_iRHS[select->iValue + 1]+
                        here->CAPsenParmNo);
            }
            return(OK);
        */
        default:
            return(E_BADPARM);
        }
}

