/**********
Copyright 2024 Xidian University
Author: 2024 Bo Li
Modified: 2024/01/27  Bo Li
Refered to NgSPICE Res/Cap related file
**********/
#include<math.h>
#include "ngspice/ngspice.h"
#include "ngspice/cktdefs.h"
#include "fecap1defs.h"
#include "ngspice/trandefs.h"
#include "ngspice/sperror.h"
#include "ngspice/suffix.h"
#define STEP(x) ((x) < 0.0 ? 0 : 1)
	/*
	BE				MNA:											RHS:
		n1		n2		i			w						
	n1| 				+1					 |			|												  |
	n2| 				-1					 |			|												  |
	ib| 1/m 	-1/m	-1			     	 |			|di/dw * w^n(t) 								  |
	w | 				-dF/di	   1/h-dF/dw|			|w(t-h)/h + F^n(t) - dF/dw*w^n(t) - dF/di*i^n(t)|
*/

int
FECAP1load(GENmodel *inModel, CKTcircuit *ckt)
/* actually load the current capacitance value into the
 * sparse matrix previously provided
 */
{
    FECAP1model *model = (FECAP1model*)inModel;
    FECAP1instance *here;
    int cond1;
    double vcap;
    double pcap;
    double geq;
    double ceq;
    double p_geq;  // equivalent conductance item in MNA for P branch
    double p_ceq;  // equivalent current item in RHS for P branch
    double Xi=1.5*sqrt(3)*model->FECAP1defEc/pow(model->FECAP1defPr,3)  //  
    int error;
    double m;

    /* check if capacitors are in the circuit or are open circuited */
    if(ckt->CKTmode & (MODETRAN|MODEAC|MODETRANOP) ) {
        /* evaluate device independent analysis conditions */
        cond1=
            ( ( (ckt->CKTmode & MODEDC) &&
                (ckt->CKTmode & MODEINITJCT) )
              || ( ( ckt->CKTmode & MODEUIC) &&
                   ( ckt->CKTmode & MODEINITTRAN) ) ) ;
        /*  loop through all the capacitor models */
        for( ; model != NULL; model = FECAP1nextModel(model)) {

            /* loop through all the instances of the model */
            for (here = FECAP1instances(model); here != NULL ;
                    here=FECAP1nextInstance(here)) {

                m = here->FECAP1m;

                if(cond1) {
                    vcap = here->FECAP1initCond;
                    pcap = here->FECAP1pinit;
                } else {
                    vcap = *(ckt->CKTrhsOld+here->FECAP1posNode) -
                           *(ckt->CKTrhsOld+here->FECAP1negNode) ;
                    pcap = *(ckt->CKTrhsOld+here->FECAP1Pbranch) ;
                }
                here->FECAP1capac =  here->FECAP1area/model->FECAP1deftFE*\
                                    (model->FECAP1defEFE+1/(Xi*(3*pcap*pcap-model->FECAP1defPr)));

                if(ckt->CKTmode & (MODETRAN | MODEAC)) {
#ifndef PREDICTOR
                    if(ckt->CKTmode & MODEINITPRED) {
                        *(ckt->CKTstate0+here->FECAP1qcap) =
                            *(ckt->CKTstate1+here->FECAP1qcap);
                    } else { /* only const caps - no poly's */
#endif /* PREDICTOR */
                        *(ckt->CKTstate0+here->FECAP1qcap) = here->FECAP1capac * vcap;
                        if((ckt->CKTmode & MODEINITTRAN)) {
                            *(ckt->CKTstate1+here->FECAP1qcap) =
                                *(ckt->CKTstate0+here->FECAP1qcap);
                        }
#ifndef PREDICTOR
                    }
#endif /* PREDICTOR */
                    error = NIintegrate(ckt,&geq,&ceq,here->FECAP1capac,
                                        here->FECAP1qcap);
                    if(error) return(error);
                    if(ckt->CKTmode & MODEINITTRAN) {
                        *(ckt->CKTstate1+here->FECAP1ccap) =
                            *(ckt->CKTstate0+here->FECAP1ccap);
                    }
                    *(here->FECAP1posPosPtr) += m * geq;
                    *(here->FECAP1negNegPtr) += m * geq;
                    *(here->FECAP1posNegPtr) -= m * geq;
                    *(here->FECAP1negPosPtr) -= m * geq;
                    *(ckt->CKTrhs+here->FECAP1posNode) -= m * ceq;
                    *(ckt->CKTrhs+here->FECAP1negNode) += m * ceq;
                } else
                    *(ckt->CKTstate0+here->FECAP1qcap) = here->FECAP1capac * vcap;
            }
        }
    }
    return(OK);
}

