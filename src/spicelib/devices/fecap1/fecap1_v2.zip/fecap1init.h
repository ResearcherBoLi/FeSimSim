#ifndef _FECAP1INIT_H
#define _FECAP1INIT_H

extern IFparm FECAP1pTable[ ];
extern IFparm FECAP1mPTable[ ];
extern char *FECAP1names[ ];
extern int FECAP1pTSize;
extern int FECAP1mPTSize;
extern int FECAP1nSize;
extern int FECAP1iSize;
extern int FECAP1mSize;

#endif
