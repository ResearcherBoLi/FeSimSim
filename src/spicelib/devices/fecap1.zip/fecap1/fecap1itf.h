/**********
Copyright 2024 Xidian University
Author: 2024 Bo Li
Modified: 2024/01/27  Bo Li
Refered to NgSPICE Res/Cap related file
**********/

#ifndef DEV_FECAP1
#define DEV_FECAP1

SPICEdev *get_fecap1_info(void);

#endif
