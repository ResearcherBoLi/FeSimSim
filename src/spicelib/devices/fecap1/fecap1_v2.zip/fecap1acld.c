/**********
Copyright 2024 Xidian University.	All rights reserved.
 Author: Bo Li	at Hangzhou Institute of Technology	 
 Modified: 2020/09/09  Bo Li
 Refered to NgSPICE Res/Cap related file
**********/
/*
 */

#include "ngspice/ngspice.h"
#include "ngspice/cktdefs.h"
#include "fecap1defs.h"
#include "ngspice/sperror.h"
#include "ngspice/suffix.h"


int
FECAP1acLoad(GENmodel *inModel, CKTcircuit *ckt)
{
    CAPmodel *model = (CAPmodel*)inModel;
    double val;
    double m;
    CAPinstance *here;

    for( ; model != NULL; model = CAPnextModel(model)) {
        for( here = CAPinstances(model); here != NULL;
                here = CAPnextInstance(here)) {

            m = here->CAPm;

            val = ckt->CKTomega * here->CAPcapac;

            *(here->CAPposPosPtr +1) += m * val;
            *(here->CAPnegNegPtr +1) += m * val;
            *(here->CAPposNegPtr +1) -= m * val;
            *(here->CAPnegPosPtr +1) -= m * val;
        }
    }
    return(OK);

}

