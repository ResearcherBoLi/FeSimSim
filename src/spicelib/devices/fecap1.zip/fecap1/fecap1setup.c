/**********
Copyright 2024 Xidian University
Author: 2024 Bo Li
Modified: 2024/01/27  Bo Li
Refered to NgSPICE Res/Cap related file
**********/
/*
 */

#include "ngspice/ngspice.h"
#include "ngspice/cktdefs.h"
#include "fecap1defs.h"
#include "ngspice/sperror.h"
#include "ngspice/suffix.h"


/*ARGSUSED*/
int
FECAP1setup(SMPmatrix *matrix, GENmodel *inModel, CKTcircuit *ckt, int *states)
        /* load the capacitor structure with those pointers needed later
         * for fast matrix loading
         */

{
    FECAP1model *model = (FECAP1model*)inModel;
    FECAP1instance *here;

    /*  loop through all the capacitor models */
    for( ; model != NULL; model = FECAP1nextModel(model)) {

        /*Default Value Processing for Model Parameters */
        if (!model->FECAP1mCapGiven) {
            model->FECAP1mCap = 0.0;
        }
        if (!model->FECAP1cjswGiven){
             model->FECAP1cjsw = 0.0;
        }
        if (!model->FECAP1defWidthGiven) {
            model->FECAP1defWidth = 10.e-6;
        }
        if (!model->FECAP1defLengthGiven) {
            model->FECAP1defLength = 0.0;
        }
        if (!model->FECAP1epsFeGiven) {
            model->FECAP1_eps_FE = 0.0;
        }            
        if (!model->FECAP1thickGiven) {
            model->FECAP1_T_FE = 1e-9;
        }
        if (!model->FECAP1defAreaGiven) {
            model->FECAP1_A_FE = 1e-14;
        }
        if (!model->FECAP1defPrGiven) {
            model->FECAP1_Pr = 27.54;
        }
        if (!model->FECAP1defEcGiven) {
            model->FECAP1_Ec = 1.175;
        }
        if (!model->FECAP1defpGiven) {
            model->FECAP1_p =18;
        }

        if (!model->FECAP1shortGiven) {
            model->FECAP1short = 0.0;
        }
        if (!model->FECAP1delGiven) {
            model->FECAP1del = 0.0;
        }
        if (!model->FECAP1tc1Given) {
            model->FECAP1tempCoeff1 = 0.0;
        }
        if (!model->FECAP1tc2Given) {
            model->FECAP1tempCoeff2 = 0.0;
        }
        if (!model->FECAP1tnomGiven) {
            model->FECAP1tnom = ckt->CKTnomTemp;
        }
        if (!model->FECAP1diGiven) {
            model->FECAP1di = 0.0;
        }
        if (!model->FECAP1depthGiven) {
            model->FECAP1d = 0.0;
        }
        if (!model->FECAP1bv_maxGiven) {
            model->FECAP1bv_max = 1e99;
        }

        if (!model->FECAP1cjGiven) {
            if((model->FECAP1depthGiven)
               && (model->FECAP1d > 0.0)) {
               if (model->FECAP1diGiven)
                 model->FECAP1cj = (model->FECAP1di * CONSTepsZero) / model->FECAP1thick;
               else
                 model->FECAP1cj = CONSTepsSiO2 / model->FECAP1thick;
            } else {
               model->FECAP1cj = 0.0;
            }
        }

        if (model->FECAP1delGiven) {
            if (!model->FECAP1narrowGiven)
                model->FECAP1narrow = 2 * model->FECAP1del;
            if (!model->FECAP1shortGiven)
                model->FECAP1short = 2 * model->FECAP1del;
        }

        /* loop through all the instances of the model */
        for (here = FECAP1instances(model); here != NULL ;
                here=FECAP1nextInstance(here)) {

            /* Default Value Processing for Capacitor Instance */
            if (!here->FECAP1lengthGiven) {
                here->FECAP1length = 0;
            }
            if (!here->FECAP1bv_maxGiven) {
                here->FECAP1bv_max = model->FECAP1bv_max;
            }


			if(here->FECAP1Pbranch == 0) { 
				error = CKTmkCur(ckt,&tmp,here->FECAP1name,"pbranch"); 
				if(error) return(error); 
				here->FECAP1Pbranch = tmp->number; 
			} 

            here->FECAP1qcap = *states;
            *states += FECAP1numStates;
            if(ckt->CKTsenInfo && (ckt->CKTsenInfo->SENmode & TRANSEN) ){
                *states += FECAP1numSenStates * (ckt->CKTsenInfo->SENparms);
            }

/* macro to make elements with built in test for out of memory */
#define TSTALLOC(ptr,first,second) \
do { if((here->ptr = SMPmakeElt(matrix, here->first, here->second)) == NULL){\
    return(E_NOMEM);\
} } while(0)

            TSTALLOC(FECAP1posPosPtr,FECAP1posNode,FECAP1posNode);
            TSTALLOC(FECAP1negNegPtr,FECAP1negNode,FECAP1negNode);
            TSTALLOC(FECAP1posNegPtr,FECAP1posNode,FECAP1negNode);
            TSTALLOC(FECAP1negPosPtr,FECAP1negNode,FECAP1posNode);

			TSTALLOC(FECAP1pbrPosPtr, FECAP1Pbranch, FECAP1posNode); 
			TSTALLOC(FECAP1pbrNegPtr, FECAP1Pbranch, FECAP1negNode); 
			TSTALLOC(FECAP1pbrPbrPtr, FECAP1Pbranch, FECAP1Pbranch); 

        }
    }
    return(OK);
}

